App = {
  web3Provider: null,
  contracts: {},

  init: async function() {

    return await App.initWeb3();
  },

  initWeb3: async function() {
      
    // Modern dapp browsers...
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      console.log("App.web3Provider");
      K = window.web3.currentProvider;
      for(let  i in K){
      console.log(i);}
      console.log(K.selectedAddress);
      try {
        // Request account access
        await window.ethereum.enable();
      } catch (error) {
        // User denied account access...
        console.error("User denied account access")
      }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
      console.log("start");
      console.log(App.web3Provider);
      console.log("end");
    }
    // If no injected web3 instance is detected, fall back to Ganache
    else {
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
    }
    web3 = new Web3(App.web3Provider);

    return App.initContract();
  },

  initContract: function() {
    $.getJSON('Adoption.json', function(data) {
      // Get the necessary contract artifact file and instantiate it with @truffle/contract

      var AdoptionArtifact = data;
      App.contracts.Adoption = TruffleContract(AdoptionArtifact);
    
      // Set the provider for our contract
      App.contracts.Adoption.setProvider(App.web3Provider);
    
      // Use our contract to retrieve and mark the adopted pets
      return App.bindEvents();
    });
    
  },

  bindEvents: function() {

    
    $(document).on('click', '#mumu', App.handleAdopt);
  },


  handleAdopt: function(event) {
    event.preventDefault();
    K = window.web3.currentProvider;
    
    console.log("jjjjj");
    console.log(K.selectedAddress);
    var petId = parseInt($(event.target).data('id'));
    var adoptionInstance;
    console.log(petId);

    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
      }
    
      var account = accounts[0];
      console.log(accounts[1]);
      console.log(account)
      App.contracts.Adoption.deployed().then(function(instance) {
        adoptionInstance = instance;
        console.log("now instance");
        console.log(instance);

    
        // Execute adopt as a transaction by sending account
        return adoptionInstance.adopt(petId, {from: account});
      }).then(function(result) {

        console.log("hello");
      }).catch(function(err) {
        console.log(err.message);
      });
    });
  }

};

$(function() {
  $(window).load(function() {
    App.init();
  });
});
