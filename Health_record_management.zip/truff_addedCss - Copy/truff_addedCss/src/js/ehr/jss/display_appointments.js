function getappointments() {

    let val=document.getElementById("display_numberof_appointments").innerHTML;
    val = parseInt(val);
    for (var i = 0; i < val; i++) {
        var input_val = document.getElementById('title').innerText;
        console.log("hbdfvfbhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
        console.log(typeof(input_val));

        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
    
        if (this.readyState == 4 && this.status == 200) {
            const  k = this.responseText;
            console.log(k);
            var p = JSON.parse(k);
            console.log(typeof(p));
            const ev = document.createElement("div");
            ev.setAttribute('id',""+p.pid+"");
            ev.innerHTML =  `<div ><center  >
            <h1 >
                information of patient `+p.pid+`
            </h1>
      
            <b><ol type=101>
            <li>NAME  - `+p.name +`  </li>
            <li>dob -`+p.dob +`   </li>
            <li>Sex   `+p.gender +`  </li>
            <li id='pid'>pid  `+p.pid +`   </li>
            <li>last_visit   `+p.last_visit +` </li>
            <li>report   `+p.discription +`   </li>
            </ol>
            </b>
            <div>
                

                <input type="text" name="Name"  id="text-`+p.pid+`" size="20"> 

            </div>
            
            </center> </div>`;
            document.getElementById("display_main").appendChild(ev);

            document.getElementById("mumu").style.display = 'block';
            document.getElementById("title").style.display = "block";
            document.getElementById("input_to_submit_disc").style.display = "block";

    
            
        }
        };
        xhttp.open("GET", "http://127.0.0.1/project/display_all_appointments.php?hosp="+input_val, true);
        xhttp.send();
      }
      
}

