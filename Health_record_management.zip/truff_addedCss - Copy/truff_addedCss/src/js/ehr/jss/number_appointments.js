function getInputValue() {
    var input_val = document.getElementById('inputId').value;
    //title change
    document.getElementById("title").innerText = input_val;
    document.getElementById("title").style.display = "block";
    // 
    console.log(input_val);
    console.log("macha");
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
  
      if (this.readyState == 4 && this.status == 200) {

        document.getElementById("butt2").style.display = "block";
        document.getElementById("display_numberof_appointments").innerHTML = this.responseText;
        document.getElementById("butt").style.display = "block";
      }
    };
    xhttp.open("GET", "http://127.0.0.1/project/get_all_appointments.php?hosp="+input_val, true);
    xhttp.send();

    }
  
  
