document.getElementById('mumu').addEventListener('click',function () {
        
        let k = (document.getElementById('input_to_submit_disc').value);
        let ki = parseInt(k);
        ///
        let discription = document.getElementById("text-"+k).value;
        console.log(discription);


        const date = new Date();

        const year = date.getFullYear();

        const month = date.getMonth() + 1;
        const day = date.getDate();


        const withHyphens = [year, month, day].join('-');
        console.log(withHyphens);



        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
        
        if (this.readyState == 4 && this.status == 200) {
                console.log(this.responseText);
                console.log(k);
                document.getElementById(k).innerHTML='SUBMITTED '+ k ;

                console.log(typeof(k));
                
        }
        };
        xhttp.open("GET", "http://127.0.0.1/project/submit_EHR_BY_hospital.php?pid="+ki+"&discription="+discription+"&curr_date="+withHyphens, true);
        xhttp.send();


        ///


        
});